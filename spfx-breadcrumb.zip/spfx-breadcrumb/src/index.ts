
/**
 * SPFx discovers components via manifests; no explicit startup code needed here.
 */
export {};
