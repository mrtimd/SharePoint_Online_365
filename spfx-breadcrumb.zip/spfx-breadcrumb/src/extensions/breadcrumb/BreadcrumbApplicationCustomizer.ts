
import { Log } from '@microsoft/sp-core-library';
import {
  BaseApplicationCustomizer,
  PlaceholderContent,
  PlaceholderName
} from '@microsoft/sp-application-base';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import styles from './Breadcrumb.module.scss';
import { IBreadcrumbApplicationCustomizerProperties } from './IBreadcrumbApplicationCustomizerProperties';

const LOG_SOURCE = 'BreadcrumbApplicationCustomizer';

interface IHubSiteData {
  title?: string;
  url?: string;
}

interface IWebInfo {
  Title: string;
  Url: string;
  ServerRelativeUrl: string;
  ParentWeb?: {
    Url: string;
    ServerRelativeUrl: string;
    Title: string;
  } | null;
}

export default class BreadcrumbApplicationCustomizer
  extends BaseApplicationCustomizer<IBreadcrumbApplicationCustomizerProperties> {

  private _topPlaceholder?: PlaceholderContent;
  private _bottomPlaceholder?: PlaceholderContent;

  public async onInit(): Promise<void> {
    Log.info(LOG_SOURCE, 'Initialized Breadcrumb Application Customizer');

    // Defaults
    if (this.properties.showHub === undefined) this.properties.showHub = true;
    if (!this.properties.maxDepth) this.properties.maxDepth = 3;
    if (!this.properties.placement) this.properties.placement = 'Top';

    this.context.placeholderProvider.changedEvent.add(this, this._render);
    this._render();

    return Promise.resolve();
  }

  private _render = async (): Promise<void> => {
    try {
      // Create placeholder
      if (this.properties.placement === 'Top') {
        if (!this._topPlaceholder) {
          this._topPlaceholder =
            this.context.placeholderProvider.tryCreateContent(PlaceholderName.Top);
        }
        if (!this._topPlaceholder || !this._topPlaceholder.domElement) return;
        await this._mount(this._topPlaceholder.domElement);
      } else {
        if (!this._bottomPlaceholder) {
          this._bottomPlaceholder =
            this.context.placeholderProvider.tryCreateContent(PlaceholderName.Bottom);
        }
        if (!this._bottomPlaceholder || !this._bottomPlaceholder.domElement) return;
        await this._mount(this._bottomPlaceholder.domElement);
      }
    } catch (e) {
      Log.error(LOG_SOURCE, e as any);
    }
  };

  private async _mount(host: HTMLElement): Promise<void> {
    const webUrl = this.context.pageContext.web.absoluteUrl;
    const siteUrl = this.context.pageContext.site.absoluteUrl;

    const isSubsite = (this.context.pageContext.web.serverRelativeUrl.toLowerCase() !==
                       this.context.pageContext.site.serverRelativeUrl.toLowerCase());

    const hub: IHubSiteData | undefined = this.properties.showHub
      ? await this._tryGetHubData(webUrl)
      : undefined;

    // Build ancestor chain for subsites
    const chain = isSubsite
      ? await this._buildParentChain(webUrl, siteUrl, this.properties.maxDepth!)
      : [];

    // Current page (optional): for simplicity, stop at Web level
    const crumbs: Array<{ title: string; url: string }> = [];

    if (hub && hub.url && hub.title) {
      crumbs.push({ title: hub.title, url: hub.url });
    }

    // Site collection root
    const siteTitle = await this._tryGetWebTitle(siteUrl) || 'Site Home';
    crumbs.push({ title: siteTitle, url: siteUrl });

    // Ancestors (from root down to immediate parent)
    chain.reverse().forEach(c => crumbs.push(c));

    // Render
    host.innerHTML = '';
    const wrapper = document.createElement('div');
    wrapper.className = styles.breadcrumbHost;

    const inner = document.createElement('div');
    inner.className = styles.wrap;

    if (isSubsite && this.properties.backOnly) {
      const parent = chain.length > 0 ? chain[chain.length - 1] : { title: 'Parent', url: siteUrl };
      const back = document.createElement('a');
      back.className = styles.backBtn;
      back.href = parent.url;
      back.innerHTML = `
        <span aria-hidden="true">←</span>
        <span>Back to ${this._escape(parent.title)}</span>
      `;
      inner.appendChild(back);
    } else {
      crumbs.forEach((c, idx) => {
        const span = document.createElement('span');
        span.className = styles.crumb;
        const link = document.createElement('a');
        link.href = c.url;
        link.textContent = c.title;
        span.appendChild(link);
        inner.appendChild(span);

        if (idx < crumbs.length - 1) {
          const sep = document.createElement('span');
          sep.className = styles.sep;
          sep.textContent = '›';
          inner.appendChild(sep);
        }
      });

      // Current web name (not a link)
      if (isSubsite) {
        const sep = document.createElement('span');
        sep.className = styles.sep;
        sep.textContent = '›';
        inner.appendChild(sep);

        const cur = document.createElement('span');
        cur.textContent = this.context.pageContext.web.title;
        inner.appendChild(cur);
      }
    }

    wrapper.appendChild(inner);
    host.appendChild(wrapper);
  }

  private _escape(text: string): string {
    const div = document.createElement('div');
    div.innerText = text;
    return div.innerHTML;
  }

  /** Returns hub title & url if the web is associated with a hub; otherwise undefined */
  private async _tryGetHubData(currentWebUrl: string): Promise<IHubSiteData | undefined> {
    try {
      const resp: SPHttpClientResponse = await this.context.spHttpClient.get(
        `${currentWebUrl}/_api/web/HubSiteData`,
        SPHttpClient.configurations.v1
      );
      if (!resp.ok) return undefined;

      const data = await resp.json();
      // May be nested JSON depending on endpoint behavior
      const parsed = typeof data === 'string' ? JSON.parse(data) : data;
      const result: IHubSiteData = {
        title: parsed?.title || parsed?.Title,
        url: parsed?.url || parsed?.SiteUrl || parsed?.siteUrl
      };
      if (result.title && result.url) {
        return result;
      }
      return undefined;
    } catch {
      return undefined;
    }
  }

  /** Try to get a web title for a given absolute site/web URL */
  private async _tryGetWebTitle(webAbsoluteUrl: string): Promise<string | undefined> {
    try {
      const resp = await this.context.spHttpClient.get(
        `${webAbsoluteUrl}/_api/web?$select=Title`,
        SPHttpClient.configurations.v1
      );
      if (!resp.ok) return undefined;
      const j = await resp.json();
      return j?.Title;
    } catch {
      return undefined;
    }
  }

  /** Build parent chain from current web up to site collection root */
  private async _buildParentChain(currentWebUrl: string, siteRootUrl: string, maxDepth: number)
    : Promise<Array<{ title: string; url: string }>> {

    const chain: Array<{ title: string; url: string }> = [];
    let cursor = currentWebUrl;
    let safety = Math.max(1, Math.min(maxDepth, 10)); // hard cap

    while (safety-- > 0) {
      try {
        const resp = await this.context.spHttpClient.get(
          `${cursor}/_api/web?$select=Title,Url,ServerRelativeUrl,ParentWeb/Url,ParentWeb/ServerRelativeUrl,ParentWeb/Title&$expand=ParentWeb`,
          SPHttpClient.configurations.v1
        );
        if (!resp.ok) break;
        const w: IWebInfo = await resp.json();

        if (!w.ParentWeb || !w.ParentWeb.Url || w.ParentWeb.Url.toLowerCase() === siteRootUrl.toLowerCase()) {
          if (w.ParentWeb && w.ParentWeb.Url && w.ParentWeb.Url.toLowerCase() != siteRootUrl.toLowerCase()) {
            chain.push({ title: w.ParentWeb.Title || 'Parent', url: w.ParentWeb.Url });
          }
          break;
        } else {
          chain.push({ title: w.ParentWeb.Title || 'Parent', url: w.ParentWeb.Url });
          cursor = w.ParentWeb.Url;
        }
      } catch {
        break;
      }
    }
    return chain;
  }
}
