
export interface IBreadcrumbApplicationCustomizerProperties {
  /** Show hub home as first crumb when hub is available */
  showHub?: boolean;
  /** Maximum number of subsite levels to show (closest ancestors first) */
  maxDepth?: number;
  /** If true, render only "Back to Parent" on subsites */
  backOnly?: boolean;
  /** Placement: 'Top' (under suite header) or 'Bottom' (above footer) */
  placement?: 'Top' | 'Bottom';
}
