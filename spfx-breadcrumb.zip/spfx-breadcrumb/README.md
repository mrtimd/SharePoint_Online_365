# SPFx Breadcrumb Extension

A ready-to-build SharePoint Framework (SPFx) **Application Customizer** that renders a breadcrumb / "Back to parent" bar. Designed for hybrid hub + site collection + subsite navigation.

## Quick start

1. Ensure Node.js LTS compatible with your SPFx toolchain (Node 18 for SPFx 1.19.x).
2. In this folder, run:

```bash
npm install
npm run build
npm run package
```

3. Upload `sharepoint/solution/spfx-breadcrumb.sppkg` to your **App Catalog** and **Deploy**.
4. Attach the extension:
   - **Tenant Wide Extensions** list (App Catalog) — recommended, or
   - Per site using **PnP PowerShell** `Add-PnPCustomAction`.

## Properties
- `showHub` (bool): show Hub Home crumb if available. Default `true`.
- `maxDepth` (number): subsite ancestor depth. Default `3`.
- `backOnly` (bool): show only "Back to Parent" on subsites. Default `false`.
- `placement` ("Top" | "Bottom"): render under suite header or above footer. Default `Top`.

## IDs
- **Solution ID:** `89053006-07e6-4534-a2b7-737a06b1b590`
- **Component ID:** `d8aa5db9-e2b5-4bc1-83aa-7a4efef3de1c`

If your tenant uses a different SPFx version, scaffold a fresh Application Customizer with Yeoman and copy the contents of `src/extensions/breadcrumb/*` plus the manifest GUIDs above.
